package com.example.kenn.adminwao;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class report extends AppCompatActivity {

    Calendar calendar;
    SimpleDateFormat simpleDateFormat;
    String Date;
    TextView date_picker,timetxt,datetxt;
    Button dtbtn,submitbtn,datebtn,timebtn;
    EditText stdedt,locationedt,victimedt,mobileedt,reportedt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.report);

        date_picker = findViewById(R.id.date_picker);
        dtbtn = findViewById(R.id.dtbtn);
        submitbtn = findViewById(R.id.submitbtn);
        stdedt = findViewById(R.id.stdedt);
        locationedt = findViewById(R.id.locationedt);
        victimedt = findViewById(R.id.victimedt);
        mobileedt = findViewById(R.id.mobileedt);
        reportedt = findViewById(R.id.reportedt);
        timetxt = findViewById(R.id.timetxt);
        datetxt= findViewById(R.id.datetxt);

        calendar = Calendar.getInstance();
        simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy h:mm:a");
        Date = simpleDateFormat.format(calendar.getTime());




        dtbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                {
                    date_picker.setText(Date);
                }
            }



            ;

        });





    }

    public void showTime(View view) {
        timepicker timePicker = new timepicker();
        timePicker.show(getFragmentManager(),"time");

    }

    public void showDate(View view) {
        datepicker datePiker = new datepicker();
        datePiker.show(getFragmentManager(), "date");
    }


}





